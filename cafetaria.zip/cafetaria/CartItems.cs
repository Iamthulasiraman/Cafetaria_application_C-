using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cafetaria
{
class CartItem
{
    public string ItemID { get; }
    public string OrderID { get; }
    public string FoodID { get; }
    public double OrderPrice { get; set; }
    public int OrderQuantity { get; set; }
    
    private static int itemCounter = 101;

    public CartItem(string orderID, string foodID, double orderPrice, int orderQuantity)
    {
        ItemID = "ITID" + itemCounter++;
        OrderID = orderID;
        FoodID = foodID;
        OrderPrice = orderPrice;
        OrderQuantity = orderQuantity;
    }
}

}