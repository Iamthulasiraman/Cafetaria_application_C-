using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cafetaria
{
    class FoodDetails
{
    public string FoodID { get; }
    public string FoodName { get; set; }
    public double FoodPrice { get; set; }
    public int AvailableQuantity { get; set; }
    
    private static int foodCounter = 101;

    public FoodDetails(string foodName, double foodPrice, int availableQuantity)
    {
        FoodID = "FID" + foodCounter++;
        FoodName = foodName;
        FoodPrice = foodPrice;
        AvailableQuantity = availableQuantity;
    }
}

}