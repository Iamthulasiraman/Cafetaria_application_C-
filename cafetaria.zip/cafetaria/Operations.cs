using System;
using System.Collections.Generic;
namespace Cafetaria
{
class Operations
{
    static UserDetails currentLoggedInUser;

    private static List<UserDetails> users = new List<UserDetails>();
    private static List<OrderDetails> orders = new List<OrderDetails>();
    private static List<CartItem> cartItems = new List<CartItem>();
    private static List<FoodDetails> foodMenu = new List<FoodDetails>
    {
        new FoodDetails("Coffee", 20, 100),
        new FoodDetails("Tea", 15, 100),
        new FoodDetails("Biscuit", 10, 100),
        new FoodDetails("Juice", 50, 100),
        new FoodDetails("Puff", 40, 100),
        new FoodDetails("Milk", 10, 100),
        new FoodDetails("Popcorn", 20, 20)
    };

    public static void DefaultData()
    {
        users.Add(new UserDetails("thulasi","kumaresan","male","987654321","ram@gmail.com","ws101",1000));
        users.Add(new UserDetails("pavi","kumaresan","female","987654320","pavi@gmail.com","ws102",1100));
    }

    public static void MainMenu()
    {
            int choice;
            bool flag = true;
            do
            {
                Console.WriteLine("Cafeteria Management System");
                Console.WriteLine("1. User Registration");
                Console.WriteLine("2. Login");
                System.Console.WriteLine("3. Exit");
                Console.Write("Enter choice: ");
                
                choice = int.Parse(Console.ReadLine());
                Console.WriteLine();
                switch (choice)
                {
                    case 1:
                        RegisterUser();
                        break;
                    case 2:
                    UserLogin();
                        break;
                    case 3:
                        flag = false;
                        break;
                    default:
                        Console.WriteLine("Invalid choice!\n");
                        break;
                }

            }while(flag);     
    }
    
    public static void RegisterUser()
    {
        Console.Write("Enter Username: ");
        string userName = Console.ReadLine();
        Console.Write("Enter Father's Name: ");
        string fatherName = Console.ReadLine();
        Console.Write("Enter Mobile Number: ");
        string mobileNumber = Console.ReadLine();
        Console.Write("Enter Email: ");
        string email = Console.ReadLine();
        Console.Write("Enter Gender (Male/Female/Other): ");
        string gender = Console.ReadLine();
        Console.Write("Enter Workstation Number (e.g., WS101): ");
        string workstation = Console.ReadLine();
        Console.Write("Enter Initial Balance: ");
        double balance = Convert.ToDouble(Console.ReadLine());
        
        UserDetails user = new UserDetails(userName, fatherName, gender, mobileNumber, email, workstation, balance);
        users.Add(user);
        
        Console.WriteLine($"User registered successfully! Your User ID: {user.UserID}\n");
    }

    public static void UserLogin()
    {
        Console.Write("Enter User ID: ");
        string userId = Console.ReadLine();
        currentLoggedInUser = users.Find(user => user.UserID == userId);
        
        if (currentLoggedInUser != null)
        {
            Console.WriteLine("Login successful!\n");
            //submenu
            SubMenu();
        }
        else
        {
            Console.WriteLine("Invalid User ID!\n");
        }
    }

    public static void SubMenu()
    {
        System.Console.WriteLine("enter the Choice :\n1.a. Show My Profile \n2. Food Order\n 3. Modify Order\n4. Cancel Order\n5. Order History\n6. Wallet Recharge\n7. Show Wallet Balance\n8. Exit");
        int choice = int.Parse(Console.ReadLine());
        switch(choice)
        {
            case 1:
            {
                //show profile
                System.Console.WriteLine($"Name : {currentLoggedInUser.Name} \nFather Name : {currentLoggedInUser.FatherName} \nMobile Number : {currentLoggedInUser.Mobile} \nMailId : {currentLoggedInUser.MailID} \nGender : {currentLoggedInUser.Gender}");
                break;
            }
            case 2:
            {
                //food order 
                FoodOrder();
                break;
            }
            case 3:
            {
                //Modify order
                break;
            }
            case 4:
            {
                // cancel order
                break;
            }
            case 5:
            {
                // Order history
                OrderHistory();
                break;
            }
            case 6:
            {
                //wallet recharge
                WalletRecharge();
                break;
            }
            case 7:
            {
                // wallet Balance
                WalletBalance();
                break;
            }
            case 8:
            {
                // exit
                break;
            }
        }

        

    }
    public static void FoodOrder()
    {
       List<CartItem> localCart = new List<CartItem>();
        OrderDetails newOrder = new OrderDetails(currentLoggedInUser.UserID);
        string choice;
        do
        {
            Console.WriteLine("Available Food Items:");
            foreach (var food in foodMenu)
                Console.WriteLine($"{food.FoodID}: {food.FoodName} - Rs.{food.FoodPrice} (Available: {food.AvailableQuantity})");
            
            Console.Write("Enter Food ID to order: ");
            string foodID = Console.ReadLine();
            FoodDetails selectedFood = foodMenu.Find(f => f.FoodID == foodID);
            
            if (selectedFood != null)
            {
                Console.Write("Enter Quantity: ");
                int quantity = Convert.ToInt32(Console.ReadLine());
                if (quantity <= selectedFood.AvailableQuantity)
                {
                    selectedFood.AvailableQuantity -= quantity;
                    localCart.Add(new CartItem(newOrder.OrderID, foodID, selectedFood.FoodPrice * quantity, quantity));
                }
                else
                {
                    Console.WriteLine("Not enough stock available.");
                }
            }
            else
            {
                Console.WriteLine("Invalid Food ID.");
            }

            Console.Write("Want to order more? (Yes/No): ");
            choice = Console.ReadLine().ToLower();
        } while (choice == "yes");

        Console.Write("Confirm order? (Yes/No): ");
        if (Console.ReadLine().ToLower() == "yes")
        {
            double totalPrice = 0;
            foreach (var item in localCart)
                totalPrice += item.OrderPrice;
            
            if (currentLoggedInUser.WalletBalance >= totalPrice)
            {
                currentLoggedInUser.DeductAmount(totalPrice);
                cartItems.AddRange(localCart);
                newOrder.TotalPrice = totalPrice;
                newOrder.OrderStatus = "Ordered";
                orders.Add(newOrder);
                Console.WriteLine($"Order placed successfully! Order ID: {newOrder.OrderID}");
            }
            else
            {
                Console.WriteLine("Insufficient balance to complete order.");
            }
        }
        else
        {
            foreach (var item in localCart)
            {
                foodMenu.Find(f => f.FoodID == item.FoodID).AvailableQuantity += item.OrderQuantity;
            }
            Console.WriteLine("Order cancelled.");
        }
    
    }
    public static void OrderHistory()
    {
        foreach(OrderDetails order in orders)
        {
            if(currentLoggedInUser.UserID.Equals(order.UserID))
            {
                System.Console.WriteLine($"{order.OrderID} {order.UserID} {order.OrderDate} {order.OrderStatus} {order.TotalPrice}");
            }
        }
    }
    public static void WalletRecharge()
    {
        bool flag = true;
        foreach(UserDetails user in users)
        {
            if (currentLoggedInUser.UserID.Equals(user.UserID))
            {
                Console.Write("Enter amount to recharge: ");
                double amount = Convert.ToDouble(Console.ReadLine());
                currentLoggedInUser.WalletRecharge(amount);
                Console.WriteLine("Wallet recharged successfully.");
                flag = false;
            }
        }
        if(flag == true)
        {
            Console.WriteLine("No user logged in.");
        }
            
    }

    public static void WalletBalance()
    {
        foreach(UserDetails user in users)
        {
            if(currentLoggedInUser.UserID.Equals(user.UserID))
            {
                System.Console.WriteLine($"Balance : {currentLoggedInUser.WalletBalance}");
            }
        }
    }
}
}
