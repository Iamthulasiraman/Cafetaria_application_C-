using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cafetaria
{
    class OrderDetails
{
    public string OrderID { get; }
    public string UserID { get; }
    public DateTime OrderDate { get; }
    public double TotalPrice { get; set; }
    public string OrderStatus { get; set; }
    
    private static int orderCounter = 1001;

    public OrderDetails(string userID)
    {
        OrderID = "OID" + orderCounter++;
        UserID = userID;
        OrderDate = DateTime.Now;
        OrderStatus = "Initiated";
        TotalPrice = 0;
    }
}

}