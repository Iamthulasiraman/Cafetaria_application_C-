﻿using System;
namespace Cafetaria;

class Program 
{
    static void Main()
    {
        Operations.MainMenu();
    }

}
