using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cafetaria
{
   
class UserDetails : PersonalDetails, IBalance
{
    public string UserID { get; }
    public string WorkStationNumber { get; set; }
    private double balance;
    public double WalletBalance => balance;
    
    private static int userCounter = 1001;

    public UserDetails(string name, string fatherName, string gender, string mobile, string mailID, string workStationNumber, double initialBalance)
        : base(name, fatherName, gender, mobile, mailID)
    {
        UserID = "SF" + userCounter++;
        WorkStationNumber = workStationNumber;
        balance = initialBalance;
    }

    public void WalletRecharge(double amount) => balance += amount;
    public void DeductAmount(double amount) => balance -= amount;
}
    
}